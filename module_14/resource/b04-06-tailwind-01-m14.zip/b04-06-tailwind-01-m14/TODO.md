### TODO

1. Understanding TailwindCSS ✅
	1. What & Why ✅
	2. Utility Classes ✅
	3. Mobile First Responsive Design ✅
	4. Customization ✅
2. Setup Guide ✅
	1. Play With CDN ✅
	2. Using CLI ✅
	3. View Live Compilation & Changes ✅
	4. Editor Setup (VSCode) ✅
3. Exploring Utility Classes 
	1. Explore the Documentation ✅
	2. Basic Utility Classes: text, font, background, spacing, sizing ✅
	3. State Utility Classes: hover, focus, active ✅
	4. Responsive Design ✅
	5. Others ✅
4. Design a Simple Responsive Page with TailwindCSS

# To Edit in Development Mode
1. Install NodeJS: https://nodejs.org/en/download
2. Open Folder in VSCode
3. Open Terminal in VSCode
4. Install Dependencies: `npm install`
5. Run Tailwind: `npx @tailwindcss/cli -i ./style.css -o ./style.out.css --watch`
