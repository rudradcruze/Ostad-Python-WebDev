0. Recap: HTML & CSS ✅
    - HTML Semantic Tags (header, footer, section, article, aside, nav, main) ✅
    - External CSS ✅
    - Universal Selector (*) ✅
    - Border ✅

1. Continuation of CSS Box Model ✅
    - Box Model (content, padding, border, margin) ✅
    - Box Sizing (content-box, border-box) ✅

2. Positioning ✅
    - Static, Relative, Absolute, Fixed, Sticky ✅
    - Topic to learn: Stacking Context, Z-index ✅

3. Flexbox ✅
    - Flex Container
        - Display Flex ✅
        - Flex Direction ✅
        - Justify Content, Align Items ✅
        - Align Content ✅
        - Gap ✅
        - Flex Wrap ✅

    - Flex Item
        - Flex Basis, Flex Grow, Flex Shrink ✅
        - Align Self ✅
        - Order ✅

4. Grid ✅
    - Grid Container
        - Grid Template ✅
        - Grid Template Columns ✅
        - Grid Template Rows ✅
        - Grid Gap ✅
        - Grid Template Areas ✅

    - Grid Item (grid-column, grid-row, grid-area)
        - Grid Column Start, Grid Column End, Grid Column Span, Grid Column ✅
        - Grid Row Start, Grid Row End, Grid Row Span, Grid Row ✅
        - Grid Area ✅

5. Grid VS Flexblox: When to use what ✅

6. Responsive Design ✅
    - Media Queries (min-width, max-width) ✅
    - Desktop-First Approach / Mobile-First Approach ✅
    - Fluid Layouts (percentages, vw, vh) ✅
    - Standard / Common Breakpoints ✅

7. Transitions ✅
8. Animations ✅
