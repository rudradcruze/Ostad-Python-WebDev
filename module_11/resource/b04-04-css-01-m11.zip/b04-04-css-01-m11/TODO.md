0. HTML Recap ✅
1. Intro to CSS ✅
    - Inline(`In`-`line`) CSS
    - Internal CSS
    - External CSS
2. Selector & Syntax ✅
3. Color ✅
4. Font / Text Styling ✅
5. Background Image ✅
6. Box Model ✅
