randFather("Red", "Chowdhury")
# f1 = Father('Cricket', "Red", "Chowdhury")
# print(f1.