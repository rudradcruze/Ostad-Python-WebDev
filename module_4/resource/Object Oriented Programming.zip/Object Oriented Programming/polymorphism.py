# poly -> multiple 
# morphism --> form 

# 1. Method Overriding
class GrandFather:
    def __init__(self):
        self.name = "Hello" # public
        self._age = 30 #protected
        self.__khajana = 30000  # private
    def greet(self):
        print("Grandfather says")

class Father(GrandFather):
    def greet(self):
        print(f"Father says. {self._age}")

class Children(Father):
    def greet(self):
        print("Children says")


gf = GrandFather()
f = Father()
c = Children()

gf.greet()
f.greet()
c.greet()
print(gf.name)
print(gf.__khajana)

# 2. Method Overloading 

class Shape:
    def area(self, a,b=10):
        return a*b
    
    

p = Shape()
print(p.area(12))
print(p.area(12,10))
    